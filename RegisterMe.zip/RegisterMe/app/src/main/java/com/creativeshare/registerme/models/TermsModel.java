package com.creativeshare.registerme.models;

import java.io.Serializable;

public class TermsModel implements Serializable {
    private String ar_content;
    private String en_content;

    public String getAr_content() {
        return ar_content;
    }

    public String getEn_content() {
        return en_content;
    }
}
