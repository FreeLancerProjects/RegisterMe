package com.creativeshare.registerme.tags;

public class Tags {

    public static String base_url = "http://rawayie.com.sa/";
    public static String IMAGE_URL = base_url + "upload/";
    public static final String IMAGE_SLIDER_URL = base_url + "upload/sliders/";
    public static final String custom_url = base_url + "upload/customs_clearances/";
    public static final String session_login = "login";
    public static final String session_logout = "logout";


}
